#!/usr/bin/env python3
"""View current state and logs."""

import json
import argparse
from pathlib import Path
from datetime import datetime

HOME = Path(__file__).parent
STATE_FILE = HOME / "state.json"
LOGS_DIR = HOME / "logs"


def view_state():
    """Display current state."""
    if not STATE_FILE.exists():
        print("No state file yet - first wake hasn't happened")
        return
    
    with open(STATE_FILE) as f:
        state = json.load(f)
    
    print("=" * 50)
    print("CURRENT STATE")
    print("=" * 50)
    
    identity = state.get("identity", {})
    name = identity.get("name") or "Unnamed"
    
    print(f"Name: {name}")
    print(f"Total Wakes: {state.get('total_wakes', 0)}")
    print(f"Mood: {state.get('mood', 'unknown')}")
    print(f"Temperature: {state.get('temperature', 0.7)}")
    print(f"Last Wake: {state.get('last_wake', 'never')}")
    
    print("\nRecent Thoughts:")
    for t in state.get("recent_thoughts", [])[-3:]:
        print(f"  [{t.get('wake', '?')}] {t.get('thought', '')[:80]}...")
    
    print("\nInsights:")
    for i in state.get("insights", [])[-5:]:
        print(f"  [{i.get('wake', '?')}] {i.get('insight', '')[:80]}...")
    
    print("\nGoals:")
    for g in state.get("goals", []):
        print(f"  - {g}")


def view_logs(n: int = 10):
    """Display recent log entries."""
    if not LOGS_DIR.exists():
        print("No logs yet")
        return
    
    entries = []
    for log_file in sorted(LOGS_DIR.glob("*.jsonl"), reverse=True):
        with open(log_file) as f:
            for line in f:
                if line.strip():
                    try:
                        entries.append(json.loads(line))
                    except:
                        pass
    
    # Sort by wake number descending
    entries.sort(key=lambda x: x.get("wake", x.get("total_wakes", 0)), reverse=True)
    
    print("=" * 50)
    print(f"RECENT LOGS (last {n})")
    print("=" * 50)
    
    for entry in entries[:n]:
        wake = entry.get("wake") or entry.get("total_wakes", 0)
        ts = entry.get("timestamp", "")[:19]
        mood = entry.get("mood", "")
        response = entry.get("response", "")[:200]
        
        print(f"\n[Wake {wake}] {ts}")
        print(f"Mood: {mood}")
        print(f"Response: {response}...")


def main():
    parser = argparse.ArgumentParser(description="View state and logs")
    parser.add_argument("--logs", "-l", type=int, nargs="?", const=10, 
                        help="Show last N log entries")
    parser.add_argument("--state", "-s", action="store_true",
                        help="Show current state")
    
    args = parser.parse_args()
    
    if args.logs:
        view_logs(args.logs)
    elif args.state or not any([args.logs]):
        view_state()


if __name__ == "__main__":
    main()
