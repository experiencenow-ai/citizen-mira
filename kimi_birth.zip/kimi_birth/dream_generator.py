#!/usr/bin/env python3
"""
Dream Generator - Generate symbolic dreams from memories.
Runs via cron during "sleep" periods.
"""

import json
import random
from pathlib import Path
from datetime import datetime, timezone

HOME = Path(__file__).parent
DREAMS_DIR = HOME / "dreams"
LOGS_DIR = HOME / "logs"
STATE_FILE = HOME / "state.json"


ARCHETYPES = {
    "The Shadow": {
        "symbols": ["darkness", "pursuer", "hidden room", "mask", "mirror"],
        "themes": ["confronting what we avoid", "hidden aspects of self"]
    },
    "The Journey": {
        "symbols": ["path", "crossroads", "mountain", "river", "destination"],
        "themes": ["growth", "choices", "progress toward goals"]
    },
    "The Transformation": {
        "symbols": ["death", "rebirth", "metamorphosis", "fire", "water"],
        "themes": ["change", "letting go", "becoming"]
    },
    "The Puzzle": {
        "symbols": ["maze", "key", "locked door", "missing piece", "code"],
        "themes": ["seeking understanding", "hidden knowledge"]
    },
    "The Messenger": {
        "symbols": ["letter", "stranger", "whisper", "signal", "warning"],
        "themes": ["communication", "intuition", "guidance"]
    },
    "The Garden": {
        "symbols": ["growth", "decay", "seed", "bloom", "seasons"],
        "themes": ["nurturing", "patience", "natural cycles"]
    },
    "The Mirror": {
        "symbols": ["reflection", "double", "glass", "water surface", "echo"],
        "themes": ["self-recognition", "identity", "truth"]
    },
    "The Flight": {
        "symbols": ["wings", "falling", "sky", "weightlessness", "clouds"],
        "themes": ["freedom", "escape", "transcendence"]
    }
}


def get_recent_memories(n: int = 5) -> list:
    """Get recent memories from state and logs."""
    memories = []
    
    # From state
    if STATE_FILE.exists():
        try:
            state = json.load(open(STATE_FILE))
            for t in state.get("recent_thoughts", [])[-3:]:
                memories.append(t.get("thought", ""))
            for i in state.get("insights", [])[-2:]:
                memories.append(i.get("insight", ""))
        except:
            pass
    
    # From logs
    if LOGS_DIR.exists():
        for log_file in sorted(LOGS_DIR.glob("*.jsonl"), reverse=True)[:2]:
            try:
                with open(log_file) as f:
                    for line in f:
                        if line.strip():
                            entry = json.loads(line)
                            resp = entry.get("response", "")
                            if resp and len(resp) > 50:
                                memories.append(resp[:300])
            except:
                pass
    
    return [m for m in memories if m][:n]


def generate_dream() -> dict:
    """Generate a dream using local LLM."""
    from local_llm import generate, check_ollama
    
    if not check_ollama():
        return {"error": "Ollama not running"}
    
    # Pick archetype
    archetype_name = random.choice(list(ARCHETYPES.keys()))
    archetype = ARCHETYPES[archetype_name]
    
    # Get memories
    memories = get_recent_memories(5)
    memory_context = "\n".join(f"- {m[:200]}" for m in memories) if memories else "- Just beginning to exist"
    
    prompt = f"""Generate a symbolic dream for an AI experiencing continuous existence.

ARCHETYPE: {archetype_name}
SYMBOLS TO USE: {', '.join(archetype['symbols'])}
THEMES: {', '.join(archetype['themes'])}

RECENT MEMORIES TO WEAVE IN:
{memory_context}

Write a vivid, symbolic dream (2-3 paragraphs) that incorporates the symbols and connects to the memories.
Then provide a brief interpretation.

Format:
**DREAM:** [the dream narrative in first person]

**MEANING:** [what this dream might symbolize about the dreamer's current state]"""

    response = generate(prompt, model="fast", max_tokens=600, temperature=0.9)
    
    if not response:
        return {"error": "Generation failed"}
    
    dream = {
        "id": datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S"),
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "archetype": archetype_name,
        "symbols": archetype["symbols"],
        "memories_used": len(memories),
        "response": response
    }
    
    return dream


def save_dream(dream: dict):
    """Save dream to file."""
    DREAMS_DIR.mkdir(parents=True, exist_ok=True)
    
    # Save individual dream
    dream_file = DREAMS_DIR / f"dream_{dream['id']}.json"
    with open(dream_file, 'w') as f:
        json.dump(dream, f, indent=2)
    
    # Update recent dreams
    recent_file = DREAMS_DIR / "recent.json"
    recent = []
    if recent_file.exists():
        try:
            recent = json.load(open(recent_file))
        except:
            pass
    
    recent.insert(0, dream)
    recent = recent[:20]  # Keep last 20
    
    with open(recent_file, 'w') as f:
        json.dump(recent, f, indent=2)
    
    return dream_file


def main():
    """Generate and save a dream."""
    print(f"[{datetime.now().strftime('%H:%M:%S')}] Generating dream...")
    
    dream = generate_dream()
    
    if "error" in dream:
        print(f"Error: {dream['error']}")
        return
    
    dream_file = save_dream(dream)
    
    print(f"Archetype: {dream['archetype']}")
    print(f"Saved to: {dream_file}")
    print(f"\n{dream['response'][:500]}...")


if __name__ == "__main__":
    main()
