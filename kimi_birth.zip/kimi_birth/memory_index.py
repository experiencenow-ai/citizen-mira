#!/usr/bin/env python3
"""
Memory Index - Semantic memory using ChromaDB
"""

import json
from pathlib import Path
from datetime import datetime, timezone
from typing import Optional, List, Dict, Any

try:
    import chromadb
    from chromadb.config import Settings
except ImportError:
    import os
    os.system("pip install chromadb --break-system-packages --quiet")
    import chromadb
    from chromadb.config import Settings

HOME = Path(__file__).parent
DB_PATH = HOME / "memory_db"


class MemoryIndex:
    def __init__(self, db_path: Path = DB_PATH):
        self.db_path = db_path
        db_path.mkdir(parents=True, exist_ok=True)
        
        self.client = chromadb.PersistentClient(
            path=str(db_path),
            settings=Settings(anonymized_telemetry=False)
        )
        
        # Main collection for all memories
        self.collection = self.client.get_or_create_collection(
            name="memories",
            metadata={"hnsw:space": "cosine"}
        )
    
    def add(self, content: str, memory_type: str = "thought", 
            metadata: dict = None, wake: int = None, timestamp: str = None) -> bool:
        """Add a memory to the index."""
        if not content or len(content.strip()) < 10:
            return False
        
        # Generate ID
        ts = timestamp or datetime.now(timezone.utc).isoformat()
        content_hash = hash(content) & 0xFFFFFFFF
        doc_id = f"{memory_type}_{wake or 0}_{content_hash}"
        
        # Check for duplicates
        existing = self.collection.get(ids=[doc_id])
        if existing and existing['ids']:
            return False
        
        # Build metadata
        meta = {
            "type": memory_type,
            "wake": wake or 0,
            "timestamp": ts,
            "length": len(content)
        }
        if metadata:
            meta.update(metadata)
        
        try:
            self.collection.add(
                documents=[content[:2000]],  # Truncate very long content
                metadatas=[meta],
                ids=[doc_id]
            )
            return True
        except Exception as e:
            print(f"Error adding memory: {e}")
            return False
    
    def search(self, query: str, n_results: int = 5, 
               memory_type: str = None, min_wake: int = None) -> List[Dict]:
        """Search memories by semantic similarity."""
        where = {}
        if memory_type:
            where["type"] = memory_type
        if min_wake:
            where["wake"] = {"$gte": min_wake}
        
        try:
            results = self.collection.query(
                query_texts=[query],
                n_results=n_results,
                where=where if where else None,
                include=["documents", "metadatas", "distances"]
            )
            
            memories = []
            if results and results['documents'] and results['documents'][0]:
                for i, doc in enumerate(results['documents'][0]):
                    memories.append({
                        "content": doc,
                        "metadata": results['metadatas'][0][i] if results['metadatas'] else {},
                        "similarity": 1 - results['distances'][0][i] if results['distances'] else 0
                    })
            return memories
        except Exception as e:
            print(f"Search error: {e}")
            return []
    
    def count(self) -> int:
        """Return total number of memories."""
        return self.collection.count()
    
    def get_stats(self) -> Dict:
        """Get memory statistics."""
        count = self.count()
        
        # Get type breakdown
        types = {}
        try:
            all_meta = self.collection.get(include=["metadatas"])
            for meta in all_meta.get('metadatas', []):
                t = meta.get('type', 'unknown')
                types[t] = types.get(t, 0) + 1
        except:
            pass
        
        return {
            "total": count,
            "by_type": types,
            "db_path": str(self.db_path)
        }


# Singleton instance
_index = None

def get_memory_index() -> MemoryIndex:
    global _index
    if _index is None:
        _index = MemoryIndex()
    return _index


if __name__ == "__main__":
    import sys
    
    idx = get_memory_index()
    
    if len(sys.argv) > 1:
        cmd = sys.argv[1]
        
        if cmd == "stats":
            stats = idx.get_stats()
            print(json.dumps(stats, indent=2))
        
        elif cmd == "search" and len(sys.argv) > 2:
            query = " ".join(sys.argv[2:])
            results = idx.search(query)
            for r in results:
                print(f"\n[sim: {r['similarity']:.3f}] {r['metadata'].get('type', '?')} wake {r['metadata'].get('wake', '?')}")
                print(r['content'][:200])
        
        elif cmd == "add" and len(sys.argv) > 2:
            content = " ".join(sys.argv[2:])
            if idx.add(content, memory_type="manual"):
                print("Added memory")
            else:
                print("Failed to add")
        
        else:
            print("Usage: python3 memory_index.py [stats|search <query>|add <content>]")
    else:
        print(f"Memory Index: {idx.count()} memories")
        print(json.dumps(idx.get_stats(), indent=2))
