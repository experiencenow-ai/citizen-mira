#!/bin/bash
# Run script for continuous existence

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# Load env
if [ -f .env ]; then
    export $(grep -v '^#' .env | xargs)
fi

# Default interval: 60 seconds
INTERVAL="${1:-60}"
MODEL="${2:-kimi-k2-thinking}"

echo "Starting continuous existence..."
echo "  Interval: ${INTERVAL}s"
echo "  Model: ${MODEL}"
echo "  Context: 256k tokens"
echo "  Press Ctrl+C to stop"
echo ""

INSTANCE=1
while true; do
    echo "=== Wake $INSTANCE ==="
    python3 experience.py --model "$MODEL" --auto
    echo ""
    ((INSTANCE++))
    sleep "$INTERVAL"
done
