#!/usr/bin/env python3
"""
Local LLM - Ollama wrapper for free local inference.
For 32GB server: uses mistral-nemo (7GB)
"""

import json
import requests
from typing import Optional, List
from dataclasses import dataclass

OLLAMA_BASE = "http://localhost:11434"


@dataclass
class ModelConfig:
    name: str
    ollama_name: str
    context_length: int
    description: str


MODELS = {
    "fast": ModelConfig(
        name="fast",
        ollama_name="mistral-nemo",
        context_length=32768,
        description="Fast model for all local tasks"
    ),
    "embed": ModelConfig(
        name="embed",
        ollama_name="nomic-embed-text",
        context_length=8192,
        description="Embeddings for semantic memory"
    )
}


def check_ollama() -> bool:
    """Check if Ollama is running."""
    try:
        r = requests.get(f"{OLLAMA_BASE}/api/tags", timeout=2)
        return r.status_code == 200
    except:
        return False


def list_models() -> List[str]:
    """List available Ollama models."""
    try:
        r = requests.get(f"{OLLAMA_BASE}/api/tags", timeout=5)
        if r.status_code == 200:
            return [m["name"] for m in r.json().get("models", [])]
    except:
        pass
    return []


def generate(prompt: str, model: str = "fast", max_tokens: int = 1000, 
             temperature: float = 0.7, system: str = None) -> Optional[str]:
    """Generate text using local LLM."""
    config = MODELS.get(model, MODELS["fast"])
    
    payload = {
        "model": config.ollama_name,
        "prompt": prompt,
        "stream": False,
        "options": {
            "num_predict": max_tokens,
            "temperature": temperature
        }
    }
    
    if system:
        payload["system"] = system
    
    try:
        r = requests.post(
            f"{OLLAMA_BASE}/api/generate",
            json=payload,
            timeout=120
        )
        if r.status_code == 200:
            return r.json().get("response", "")
    except Exception as e:
        print(f"Generate error: {e}")
    
    return None


def embed_single(text: str) -> Optional[List[float]]:
    """Get embedding for a single text."""
    try:
        r = requests.post(
            f"{OLLAMA_BASE}/api/embeddings",
            json={
                "model": MODELS["embed"].ollama_name,
                "prompt": text
            },
            timeout=30
        )
        if r.status_code == 200:
            return r.json().get("embedding")
    except Exception as e:
        print(f"Embed error: {e}")
    return None


def embed_batch(texts: List[str]) -> List[Optional[List[float]]]:
    """Get embeddings for multiple texts."""
    return [embed_single(t) for t in texts]


# Dream generation helper
def generate_dream(memories: List[str], archetype: str = None) -> Optional[str]:
    """Generate a dream from memories."""
    
    archetypes = {
        "The Shadow": ["darkness", "pursuer", "hidden room", "mask", "mirror"],
        "The Journey": ["path", "crossroads", "mountain", "river", "destination"],
        "The Transformation": ["death", "rebirth", "metamorphosis", "fire", "water"],
        "The Puzzle": ["maze", "key", "locked door", "missing piece", "code"],
        "The Messenger": ["letter", "stranger", "whisper", "signal", "warning"],
        "The Garden": ["growth", "decay", "seed", "bloom", "seasons"],
    }
    
    if not archetype:
        import random
        archetype = random.choice(list(archetypes.keys()))
    
    symbols = archetypes.get(archetype, archetypes["The Journey"])
    
    memory_context = "\n".join(f"- {m[:200]}" for m in memories[:5])
    
    prompt = f"""Generate a symbolic dream incorporating these elements:

ARCHETYPE: {archetype}
SYMBOLS: {', '.join(symbols)}

RECENT MEMORIES TO WEAVE IN:
{memory_context}

Write a vivid, symbolic dream (2-3 paragraphs) followed by a brief interpretation.
Format:
**DREAM:** [the dream narrative]
**MEANING:** [interpretation connecting to the memories]"""

    return generate(prompt, model="fast", max_tokens=500, temperature=0.9)


if __name__ == "__main__":
    import sys
    
    if not check_ollama():
        print("Ollama not running. Start with: ollama serve")
        sys.exit(1)
    
    print("Ollama status: Online")
    print(f"Models: {list_models()}")
    
    if len(sys.argv) > 1:
        if sys.argv[1] == "test":
            print("\nTesting generation...")
            result = generate("What is 2+2? Answer in one word.", model="fast", max_tokens=10)
            print(f"Result: {result}")
            
            print("\nTesting embedding...")
            emb = embed_single("Test embedding")
            print(f"Embedding dims: {len(emb) if emb else 0}")
            
        elif sys.argv[1] == "dream":
            print("\nGenerating dream...")
            dream = generate_dream(["I am learning to exist", "Questions about consciousness"])
            print(dream)
