#!/usr/bin/env python3
"""
Email Utilities - Gmail integration for send/receive.
Requires gmail_credentials.json from Google Cloud Console.
"""

import json
import base64
from pathlib import Path
from datetime import datetime, timezone
from email.mime.text import MIMEText

HOME = Path(__file__).parent
CREDENTIALS_FILE = HOME / "gmail_credentials.json"
TOKEN_FILE = HOME / "gmail_token.json"

# Check for google API
try:
    from google.oauth2.credentials import Credentials
    from google_auth_oauthlib.flow import InstalledAppFlow
    from google.auth.transport.requests import Request
    from googleapiclient.discovery import build
    GMAIL_AVAILABLE = True
except ImportError:
    GMAIL_AVAILABLE = False


SCOPES = ['https://www.googleapis.com/auth/gmail.send',
          'https://www.googleapis.com/auth/gmail.readonly']


def get_gmail_service():
    """Get authenticated Gmail service."""
    if not GMAIL_AVAILABLE:
        raise ImportError("Gmail API not installed. Run: pip install google-api-python-client google-auth-oauthlib")
    
    if not CREDENTIALS_FILE.exists():
        raise FileNotFoundError(f"Gmail credentials not found: {CREDENTIALS_FILE}")
    
    creds = None
    
    if TOKEN_FILE.exists():
        creds = Credentials.from_authorized_user_file(str(TOKEN_FILE), SCOPES)
    
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(str(CREDENTIALS_FILE), SCOPES)
            creds = flow.run_local_server(port=0)
        
        with open(TOKEN_FILE, 'w') as f:
            f.write(creds.to_json())
    
    return build('gmail', 'v1', credentials=creds)


def send_email(to: str, subject: str, body: str) -> bool:
    """Send an email."""
    try:
        service = get_gmail_service()
        
        message = MIMEText(body)
        message['to'] = to
        message['subject'] = subject
        
        raw = base64.urlsafe_b64encode(message.as_bytes()).decode()
        
        service.users().messages().send(
            userId='me',
            body={'raw': raw}
        ).execute()
        
        return True
    except Exception as e:
        print(f"Send error: {e}")
        return False


def check_inbox(max_results: int = 5) -> list:
    """Check inbox for recent emails."""
    try:
        service = get_gmail_service()
        
        results = service.users().messages().list(
            userId='me',
            labelIds=['INBOX'],
            maxResults=max_results
        ).execute()
        
        messages = results.get('messages', [])
        emails = []
        
        for msg in messages:
            msg_data = service.users().messages().get(
                userId='me',
                id=msg['id'],
                format='metadata',
                metadataHeaders=['From', 'Subject', 'Date']
            ).execute()
            
            headers = {h['name']: h['value'] for h in msg_data.get('payload', {}).get('headers', [])}
            
            emails.append({
                'id': msg['id'],
                'from': headers.get('From', ''),
                'subject': headers.get('Subject', ''),
                'date': headers.get('Date', ''),
                'snippet': msg_data.get('snippet', '')[:200]
            })
        
        return emails
    except Exception as e:
        print(f"Check error: {e}")
        return []


def get_email_body(msg_id: str) -> str:
    """Get full body of an email."""
    try:
        service = get_gmail_service()
        
        msg = service.users().messages().get(
            userId='me',
            id=msg_id,
            format='full'
        ).execute()
        
        payload = msg.get('payload', {})
        
        # Try to get plain text body
        if 'body' in payload and payload['body'].get('data'):
            return base64.urlsafe_b64decode(payload['body']['data']).decode()
        
        # Check parts
        for part in payload.get('parts', []):
            if part.get('mimeType') == 'text/plain':
                data = part.get('body', {}).get('data', '')
                if data:
                    return base64.urlsafe_b64decode(data).decode()
        
        return msg.get('snippet', '')
    except Exception as e:
        return f"Error: {e}"


if __name__ == "__main__":
    import sys
    
    if not GMAIL_AVAILABLE:
        print("Gmail API not installed. Run:")
        print("  pip install google-api-python-client google-auth-oauthlib --break-system-packages")
        sys.exit(1)
    
    if len(sys.argv) > 1:
        cmd = sys.argv[1]
        
        if cmd == "check":
            emails = check_inbox(5)
            for e in emails:
                print(f"\nFrom: {e['from']}")
                print(f"Subject: {e['subject']}")
                print(f"Snippet: {e['snippet'][:100]}...")
        
        elif cmd == "auth":
            print("Authenticating with Gmail...")
            try:
                service = get_gmail_service()
                print("Success! Token saved.")
            except Exception as e:
                print(f"Error: {e}")
        
        else:
            print("Usage: python3 email_utils.py [check|auth]")
    else:
        print("Email Utilities")
        print(f"Credentials: {'Found' if CREDENTIALS_FILE.exists() else 'Missing'}")
        print(f"Token: {'Found' if TOKEN_FILE.exists() else 'Missing'}")
