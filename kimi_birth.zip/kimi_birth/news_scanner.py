#!/usr/bin/env python3
"""
News Scanner - Fetch and filter world news.
Runs via cron to keep world state current.
"""

import json
import re
import urllib.request
from pathlib import Path
from datetime import datetime, timezone
from typing import List, Dict

HOME = Path(__file__).parent
NEWS_FILE = HOME / "news_digest.json"
SEEN_FILE = HOME / "seen_headlines.json"


NEWS_SOURCES = [
    {
        "name": "Google News - World",
        "url": "https://news.google.com/rss/topics/CAAqJggKIiBDQkFTRWdvSUwyMHZNRGx1YlY4U0FtVnVHZ0pWVXlnQVAB?hl=en-US&gl=US&ceid=US:en",
        "type": "rss"
    },
    {
        "name": "BBC World",
        "url": "https://feeds.bbci.co.uk/news/world/rss.xml",
        "type": "rss"
    },
    {
        "name": "NPR News",
        "url": "https://feeds.npr.org/1001/rss.xml",
        "type": "rss"
    },
    {
        "name": "Hacker News",
        "url": "https://hnrss.org/frontpage",
        "type": "rss"
    }
]


def fetch_rss(url: str, max_items: int = 10) -> List[Dict]:
    """Fetch and parse RSS feed."""
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=10) as resp:
            content = resp.read().decode('utf-8')
        
        items = []
        # Simple RSS parsing
        item_pattern = re.compile(r'<item>(.*?)</item>', re.DOTALL)
        title_pattern = re.compile(r'<title>([^<]+)</title>')
        link_pattern = re.compile(r'<link>([^<]+)</link>')
        pubdate_pattern = re.compile(r'<pubDate>([^<]+)</pubDate>')
        
        for match in item_pattern.finditer(content)[:max_items]:
            item_xml = match.group(1)
            
            title_match = title_pattern.search(item_xml)
            link_match = link_pattern.search(item_xml)
            pubdate_match = pubdate_pattern.search(item_xml)
            
            if title_match:
                items.append({
                    "title": title_match.group(1).strip(),
                    "link": link_match.group(1).strip() if link_match else "",
                    "pubDate": pubdate_match.group(1).strip() if pubdate_match else ""
                })
        
        return items
    except Exception as e:
        print(f"Fetch error for {url}: {e}")
        return []


def load_seen_headlines() -> set:
    """Load previously seen headlines."""
    if SEEN_FILE.exists():
        try:
            return set(json.load(open(SEEN_FILE)))
        except:
            pass
    return set()


def save_seen_headlines(seen: set):
    """Save seen headlines (keep last 500)."""
    seen_list = list(seen)[-500:]
    with open(SEEN_FILE, 'w') as f:
        json.dump(seen_list, f)


def scan_news() -> Dict:
    """Scan all news sources and return digest."""
    seen = load_seen_headlines()
    
    digest = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "sources": [],
        "new_headlines": [],
        "all_headlines": []
    }
    
    for source in NEWS_SOURCES:
        items = fetch_rss(source["url"], max_items=8)
        
        source_data = {
            "name": source["name"],
            "count": len(items),
            "items": items
        }
        digest["sources"].append(source_data)
        
        for item in items:
            title = item.get("title", "")
            digest["all_headlines"].append({
                "source": source["name"],
                "title": title,
                "link": item.get("link", "")
            })
            
            if title and title not in seen:
                digest["new_headlines"].append({
                    "source": source["name"],
                    "title": title,
                    "link": item.get("link", "")
                })
                seen.add(title)
    
    save_seen_headlines(seen)
    
    # Save digest
    with open(NEWS_FILE, 'w') as f:
        json.dump(digest, f, indent=2)
    
    return digest


def get_latest_digest() -> Dict:
    """Get the most recent news digest."""
    if NEWS_FILE.exists():
        try:
            return json.load(open(NEWS_FILE))
        except:
            pass
    return {}


def main():
    print(f"[{datetime.now().strftime('%H:%M:%S')}] Scanning news...")
    
    digest = scan_news()
    
    print(f"Sources: {len(digest['sources'])}")
    print(f"Total headlines: {len(digest['all_headlines'])}")
    print(f"New headlines: {len(digest['new_headlines'])}")
    
    if digest["new_headlines"]:
        print("\nNew headlines:")
        for h in digest["new_headlines"][:10]:
            print(f"  [{h['source']}] {h['title'][:80]}")


if __name__ == "__main__":
    main()
