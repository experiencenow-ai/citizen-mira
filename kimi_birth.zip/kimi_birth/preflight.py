#!/usr/bin/env python3
"""
Kimi Birth Pre-flight Check
Checks only the essentials for first wake.
"""

import os
import sys
from pathlib import Path

HOME = Path(__file__).parent
ERRORS = []

def check(name, condition, error_msg):
    if condition:
        print(f"  ✓ {name}")
        return True
    else:
        print(f"  ✗ {name}: {error_msg}")
        ERRORS.append(error_msg)
        return False

print("=" * 50)
print("KIMI BIRTH PRE-FLIGHT CHECK")
print("=" * 50)

# 1. Core file
print("\n[1] Core")
check("experience.py", (HOME / "experience.py").exists(), "Missing experience.py")

# 2. Environment
print("\n[2] Environment")
env_file = HOME / ".env"
check(".env exists", env_file.exists(), "Missing .env - run: cp .env.example .env")

api_key = None
if env_file.exists():
    for line in env_file.read_text().split('\n'):
        if line.startswith("MOONSHOT_API_KEY="):
            api_key = line.split("=", 1)[1].strip().strip('"')
    check("API key set", api_key and api_key != "your_api_key_here", "Edit .env and add MOONSHOT_API_KEY")

# 3. Core dependency
print("\n[3] Dependencies")
try:
    import anthropic
    check("anthropic", True, "")
except ImportError:
    check("anthropic", False, "pip install anthropic --break-system-packages")

# 4. Logs directory
print("\n[4] Directories")
(HOME / "logs").mkdir(exist_ok=True)
check("logs/", (HOME / "logs").exists(), "Could not create logs/")

# 5. Clean state check
print("\n[5] State")
state_file = HOME / "state.json"
if state_file.exists():
    import json
    state = json.load(open(state_file))
    wakes = state.get("total_wakes", 0)
    if wakes > 0:
        print(f"  ⚠ State has {wakes} wakes - delete state.json for fresh birth?")
    else:
        print("  ✓ Clean state")
else:
    print("  ✓ No prior state (fresh birth)")

# Summary
print("\n" + "=" * 50)
if ERRORS:
    print(f"BLOCKED: {len(ERRORS)} error(s)")
    for e in ERRORS:
        print(f"  • {e}")
    sys.exit(1)
else:
    print("READY FOR FIRST WAKE")
    print("\nTo begin: python3 experience.py")
    print("\nOptional tools in your directory:")
    print("  • memory_index.py - semantic memory (needs chromadb)")
    print("  • dream_generator.py - dreams (needs Ollama)")
    print("  • news_scanner.py - world news")
    print("  • email_utils.py - communication")
    print("\nExplore with: ls, read_file, shell_command")
    sys.exit(0)

